// scripts.js
let meritCount = 0;

function hitMuyu() {
     meritCount += 1;
     document.getElementById('merit-count').textContent = meritCount;
     var sound = document.getElementById('muyu-sound');
     sound.play();
}